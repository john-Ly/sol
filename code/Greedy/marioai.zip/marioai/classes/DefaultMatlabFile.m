
%% SimpleMLPAgent
% BasicFitness 
Attempts = [1:1];
% BasicFitness 
BasicFitness = [-8.810577392578125 ];
plot(Attempts,BasicFitness, '.')